package com.day5.thread.demo;

class YourThread implements Runnable{		
	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println(Thread.currentThread().getName()+ "\t" + i);	
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}	
}
public class ThreadDemo2 {
	public static void main(String[] args) {
		//1. create Thread object
		/*YourThread yourThread1 = new YourThread();
		YourThread yourThread2 = new YourThread();
		Thread thread1 = new Thread(yourThread1, "ThreadONE");
		Thread thread2 = new Thread(yourThread2, "ThreadTWO"); */
		
		/*Thread thread1 = new Thread(new YourThread(), "ThreadONE");
		Thread thread2 = new Thread(new YourThread(), "ThreadTWO");
		
		
		//2. call start method - it creates separate stack for the thread
		thread1.start();
		thread2.start(); */
		
		new Thread(new YourThread(), "ThreadONE").start();
		new Thread(new YourThread(), "ThreadTWO").start();
		
	}

}
