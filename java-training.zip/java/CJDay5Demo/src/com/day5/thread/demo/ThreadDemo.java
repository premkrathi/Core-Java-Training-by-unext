package com.day5.thread.demo;

class MyThread extends Thread{	
	public MyThread(String name) {
		super(name);
	}
	
	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println(this.getName() + "\t" + i);
			/*try {
				sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}*/
		}
	}
}
public class ThreadDemo {
	public static void main(String[] args) {
		//1. create Thread object
		MyThread thread1 = new MyThread("ThreadONE"); 
		MyThread thread2 = new MyThread("ThreadTWO"); 
		//2. call start method - it creates separate stack for the thread
		thread1.start();
		thread2.start();
		
	}

}
