package com.day5.thread.demo;

class Table{
	public void printTable(int num) {
		for(int i=1; i<=10; i++) {
			System.out.println(num*i);
		}
	}
}

class SomeThread extends Thread{
	private Table table;
	private int num;
	public SomeThread(Table table, int num) {
		this.table = table;
		this.num = num;
	}
	public void run() {
		table.printTable(num);
	}
}

public class RaceConditionDemo {
	public static void main(String[] args) {
		Table table = new Table(); //resource objects
		SomeThread thread1 = new SomeThread(table, 5);
		SomeThread thread2 = new SomeThread(table, 6);
		thread1.start();
		thread2.start();
	}

}
