package com.day5.thread.demo;
// class MyThread is defined in ThreadDemo.java

public class ThreadDemo3 {
	public static void main(String[] args) {
		MyThread thread1 = new MyThread("ThreadONE"); 
		MyThread thread2 = new MyThread("ThreadTWO"); 
		
		thread1.setPriority(Thread.MAX_PRIORITY);
		thread2.setPriority(Thread.MIN_PRIORITY);
		thread2.start();
		thread1.start();
		
	}

}
