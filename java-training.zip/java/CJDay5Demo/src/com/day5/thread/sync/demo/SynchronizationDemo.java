package com.day5.thread.sync.demo;

class Table{
	//public synchronized void printTable(int num) {
	public  void printTable(int num) {
		for(int i=1; i<=10; i++) {
			System.out.println(num*i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class SomeThread extends Thread{
	private Table table;
	private int num;
	public SomeThread(Table table, int num) {
		this.table = table;
		this.num = num;
	}
	public  void run() {
		synchronized(table) {
			table.printTable(num);
		}
	}
}

public class SynchronizationDemo {
	public static void main(String[] args) {
		Table table = new Table(); //resource objects
		SomeThread thread1 = new SomeThread(table, 5);
		SomeThread thread2 = new SomeThread(table, 1000);
		thread1.start();
		thread2.start();
	}

}
