package com.day5.demo;

public class ElectionDemo {
	public static void main(String[] args) {
		System.out.println("Voting App...");
		int age = 17;
		try {
		/*if(age < 18)
			throw new NotEligibleException(); */
			if(age < 18)
				throw new NotEligibleException("Sorry! You are not eligible to vote!");	
		}catch(NotEligibleException exception) {
			exception.printStackTrace();
			//System.out.println(exception.getMessage());
		}	

	}

}
