package com.day5.demo;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("Hi Hi !!");
		int i = 10;
		int j = 0;
		int k = 0;		
		try {
			k = i/j; // throw new ArithmeticException()
			System.out.println("Value of k : " + k);
		}catch(ArithmeticException exception) {
			//System.out.println("------Divide by ZERO not allowed...");
			exception.printStackTrace();			
			//System.out.println(exception.getMessage());			
		}finally {
			System.out.println("Finally here........");
		}
		
		
		System.out.println("Bye Bye !!");

	}

}
