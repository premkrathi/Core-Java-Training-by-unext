package com.day5.demo;

class Election{		
	public void eligiblityCheck(int age) throws NotEligibleException  {
		if(age < 18)
			throw new NotEligibleException("Sorry! You are not eligible to vote!");			
	}	
	public void validate(int age) throws NotEligibleException {
		//
		eligiblityCheck(age);
	}
	
}
public class ElectionDemo3 {
	public static void main(String[] args) throws NotEligibleException {
		System.out.println("Voting App...");
		int age = 17;
		Election election = new Election();
		/*try {
			election.eligiblityCheck(age);
		} catch (NotEligibleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		election.validate(age);
		System.out.println("Bye Bye ......");

	}

}
