package com.day5.demo;

public class ExceptionDemo {

	public static void main(String[] args) {
		System.out.println("Hi Hi !!");
		int i = 10;
		int j = 0;
		int k = 0;			
		k = i/j; 
		System.out.println("Value of k : " + k);	
		
		System.out.println("Bye Bye !!");
	}

}
