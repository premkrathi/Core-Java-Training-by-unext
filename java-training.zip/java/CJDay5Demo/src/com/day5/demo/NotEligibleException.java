package com.day5.demo;

public class NotEligibleException extends Exception {

	public NotEligibleException() {
		super("Age less than 18 - Not eligible");
	}
	
	public NotEligibleException(String message) {
		super(message);
	}
	
}
