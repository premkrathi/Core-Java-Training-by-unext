package com.day5.demo;

/*class Election{	
	
	public void eligiblityCheck(int age) {
		try {
		if(age < 18)
			throw new NotEligibleException("Sorry! You are not eligible to vote!");	
		}catch(NotEligibleException ne) {
			ne.printStackTrace();
		}
	}	
	/*public void validate(int age) {
		//
		eligiblityCheck(age);
	}
	
} */
public class ElectionDemo2 {
	public static void main(String[] args) {
		System.out.println("Voting App...");
		int age = 17;
		Election election = new Election();
		election.eligiblityCheck(age);
		//election.validate(age);

	}

}
