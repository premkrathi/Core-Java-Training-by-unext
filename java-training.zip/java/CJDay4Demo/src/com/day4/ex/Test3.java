package com.day4.ex;

public class Test3 {
	public static void main(String[] args) {
		System.out.println("Hi Hi !!");
		int i = 10;
		int j = 10;
		int k = 0;
		String name = null;
		try {
			k = i/j; // A
			
			System.out.println(name.toLowerCase()); //N 
			System.out.println("Value of k : " + k);
		}catch(RuntimeException exception) {
			//System.out.println("------Divide by ZERO not allowed...");
			exception.printStackTrace();
		}
		
		
		System.out.println("Bye Bye !!");

	}

}
