package com.day4.ex;

public class Test {
	public static void main(String[] args) {
		System.out.println("Hi Hi !!");
		int i = 10;
		int j = 0;
		int k = 0;
		
		try {
			k = i/j; // throw new ArithmeticException()
			System.out.println("Value of k : " + k);
		}catch(Exception exception) {
			System.out.println("------Divide by ZERO not allowed...");
			exception.printStackTrace();
		}
		
		
		System.out.println("Bye Bye !!");

	}

}
