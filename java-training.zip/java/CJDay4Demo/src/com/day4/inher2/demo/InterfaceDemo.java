package com.day4.inher2.demo;

interface I1{
	public static final double PI = 3.14; //no need to write public static final, it is by default
	public abstract double method1(); 
	void method2();
}

interface I2{
	double method3(); 
	void method4();
}

class Info {
	//....
}

 class Sample extends Info implements I1,I2{
	public double method1() {
		return 0.0;
	}
	
	public void method2() {
		System.out.println("Method 2 of Sample");
	}

	@Override
	public double method3() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void method4() {
		// TODO Auto-generated method stub
		
	}
}


public class InterfaceDemo {
	public static void main(String[] args) {
		
		System.out.println(I1.PI);
		

	}

}
