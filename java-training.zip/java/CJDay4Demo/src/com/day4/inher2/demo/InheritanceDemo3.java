package com.day4.inher2.demo;

//draw a Shape... 
// calculate area of a Shape

// Circle is a Shape
// Rectangle is a Shape
// Triangle is a Shape

//abstract class
abstract class Shape{
	public abstract double calculateArea();
	//public abstract double calculateCircumference();
	//void info();
	/*public void info() {
		System.out.println("This is a Shape...");
	}*/
}

//concrete class
class Circle extends Shape{
	private double radius = 20.0;
	//......
	@Override
	public double calculateArea() {
		return 3.14 * radius * radius;
	}
	
}

class Rectangle extends Shape{
	private double length = 5.0;
	private double width = 4.0;
	//....
	@Override
	public double calculateArea() {
		return length * width;
	}	
}

final class Square extends Rectangle{
	
}

class Triangle extends Shape{
	private double base = 10.0;
	private double height = 5.0;
	@Override
	public double calculateArea() {
		return 0.5 * base * height;
	}	
}

public class InheritanceDemo3 {
	public static void printArea(Shape shape) {
		double area = shape.calculateArea();
		System.out.println(area);
	}
	/*public static void printArea(Circle circle) {
		double area = circle.calculateArea();
		System.out.println(area);
	}
	
	public static void printArea(Rectangle rectangle) {
		double area = rectangle.calculateArea();
		System.out.println(area);
	}
	public static void printArea(Triangle triangle) {
		double area = triangle.calculateArea();
		System.out.println(area);
	}*/	
	
	
	public static void main(String[] args) {
		//Shape shape = new Shape(); // can't create object of abstract class
		//super class reference can point to sub class object
		/*Shape shape = new Rectangle();		
		shape.calculateArea();*/	
		
		Shape shape = new Triangle();
		InheritanceDemo3.printArea(shape);	
		
	}

}
