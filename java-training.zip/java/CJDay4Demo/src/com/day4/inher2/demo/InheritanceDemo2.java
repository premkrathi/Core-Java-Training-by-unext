package com.day4.inher2.demo;

class Person {	 
	public  void show() {
		 System.out.println("Showing Person details............");
	 }	 
	}

class Employee extends Person{
	@Override
	 public  void show() {
		 System.out.println("Showing Employee details............");
	 }	
}
class Student extends Person{
	//.......
	public  void show() {
		 System.out.println("Showing Student details............");
	 } 
}
class Customer extends Person{
	//.....
	/*public  void show() {
		 System.out.println("Showing Customer details............");
	 }*/
} 


public class InheritanceDemo2 {
	public static void main(String[] args) {
		//Person person = new Person();
		//super class reference can point to sub class object
		
		Person person = new Employee();
		person.show();	
		
		person = new Student();
		person.show();
		
		person = new Customer();
		person.show();
		
		
	}

}
