package com.day3.demo;


// implicitly Object will be super class of Book
class Book{
	private int bookId;
	private String author;
	private double price;

	public Book(int bookId, String author, double price) {
		super();
		this.bookId = bookId;
		this.author = author;
		this.price = price;
	}	

	@Override
	public String toString() {
		return bookId + "\t" + author + "\t" + price;
	}

	@Override
	public boolean equals(Object obj) {
		Book book = (Book) obj;
		
		if(this == book)
			return true;
		
		if(book !=null )
			if( (this.author.equals(book.author)))
				return true;
			else
				return false;
		return false;
	}

	//setters and getters	
}
public class CosmicDemo {
	public static void main(String[] args) {
		Book book1 = new Book(1111, "Bala Guruswamy", 399.00);
		//Book book2 = new Book(1111, "Bala Guruswamy", 399.00);
		Book book2 = book1;
		System.out.println(book1);
		System.out.println(book2);

		System.out.println(book1.equals(book2));

	}

}
