package com.day3.demo;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.setEmpId(111);
		employee.setEmpName("Rama");
		
		Address address = new Address();
		address.setHouseNo(10);
		address.setStreetName("Sringeri Nagar");
		address.setCity("Bengaluru");		
		
		employee.setAddress(address);
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		System.out.println(employee.getAddress().getHouseNo());
		System.out.println(employee.getAddress().getCity());
		
		//System.out.println(employee);
		
		
	}

}
