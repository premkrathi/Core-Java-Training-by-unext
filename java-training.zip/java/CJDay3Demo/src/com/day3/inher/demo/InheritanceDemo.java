package com.day3.inher.demo;

class Person {
	 private String name;
	 private int age;
	 final int VAL = 100;
	 public Person() {
		 System.out.println("Person Constructor..." );
	 }
	 public Person(String name) {
		 System.out.println("Person Parameterized Constructor....");
	 }
	
	 public  void show() {
		 System.out.println(name + "\t" + age);
	 }
	 
	 
	 public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	} 	
	 
}

 class Employee extends Person{
	private int empId;
	public Employee() {
		super("Ram");
		System.out.println("Employee Constructor...");
	 }
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public void show() {
		 System.out.println(empId + "\t" + getName() + "\t" + getAge());
	 }
	
}

class Manager extends Employee{
	public Manager() {
		super();
		 System.out.println("Manager Constructor...");
	 }
}


public class InheritanceDemo {
	public static void main(String[] args) {
		Employee employee = new Employee();
		
		employee.setEmpId(1111); // from Employee class
		employee.setName("Ram"); // from Person class
		employee.setAge(33); //from Person class*/
		employee.show();
		
		System.out.println(employee);
		//Manager manager = new Manager();
	}

}
