
public class StaticDemo {
	public int num; // instance variable
	private static int count;  //class variable
	
	public StaticDemo() {
		num++;
		count++;
	}
		
	public void show() {
		System.out.println("num : " + num +"\tcount : " +count);
	}
	
	public static void display() {
		System.out.println("count : " +count);
	}
	
	public static void main(String[] args) {
		StaticDemo.display();
		System.out.println(StaticDemo.count);
		
		StaticDemo demo = new StaticDemo();
		demo.show();
		StaticDemo demo1 = new StaticDemo();
		demo1.show();
		StaticDemo demo2 = new StaticDemo();
		demo2.show();
		StaticDemo.display();
	}

}
