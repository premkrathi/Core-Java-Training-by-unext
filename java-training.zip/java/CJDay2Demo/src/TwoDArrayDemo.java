
public class TwoDArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] arr = new int[3];
		
		//int [][] marks = new int[3][3]; //row 2, column 3
		int [][] marks = {
				{20,30,20},
				{31,45,23},
				{20,34},
				{23,34,54,21}
		};
		for(int i = 0; i<marks.length; i++) {
			for(int j = 0; j<marks[i].length; j++) {
				System.out.print(marks[i][j] + " ");
			}
			System.out.println();
		}
		
		
		
		
		
		//Jagged Array in java

	}

}
