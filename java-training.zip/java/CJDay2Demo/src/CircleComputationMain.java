import java.util.Scanner;

class CircleComputation{
	private double radius;
	public double calculateArea(double radius) {
		double area = 0.0;
		// logic for calculating Area
		return area;
	}	
}


public class CircleComputationMain {	
	public static void main(String[] args) {
		CircleComputation computation  = new CircleComputation();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the radius : ");
		double radius = scanner.nextDouble();
	
		double area = computation.calculateArea(radius);
		System.out.println(area);
	}

}
