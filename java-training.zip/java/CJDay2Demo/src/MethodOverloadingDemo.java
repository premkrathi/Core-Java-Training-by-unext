class Book{
	private int bookId;
	private String bookTitle;
	
	public Book() {
		bookId = 111;
		bookTitle = "Java Book";
	}
	
	public Book(int bookId, String bookTitle) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
	}
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public void show() {
		System.out.println(bookId + "\t" + bookTitle);
	}
	
	public void show(int bookId) {
		System.out.println(bookId);
	}
	
	
	public boolean search(int bookId) {
		
		//logic for searching
		return false;
	}
	
	
	public boolean search(String bookTitle) {
		
		//logic for searching
		return false;
	}
	
	
}



public class MethodOverloadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
