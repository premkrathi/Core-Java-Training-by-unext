package in.manipal;

public class Sample {
	int num1;
	int num2;
	
	public Sample() {
		num1 = 10;
		num2 = 20;
	}
	
	public Sample(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}
	
	public int sum(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
		return this.num1 + this.num2;
	}
	
	public int sum() {
		return this.num1 + this.num2;
	}
	public static void main(String [] args) {
		Sample sample = new Sample();
		int total = sample.sum();
		System.out.println(total);
		
		
		Sample sample1 = new Sample(100,200);
		total = sample1.sum();
		System.out.println(total);
		
		
	}
}
