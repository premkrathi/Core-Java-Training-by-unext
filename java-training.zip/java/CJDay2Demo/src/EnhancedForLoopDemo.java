
public class EnhancedForLoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int [] arr = new int[3];
		
		for(int a:arr) {
			System.out.println(a);
		}
		
	}

}
