
public class EmployeeMain {

	public static void main(String[] args) {
		Employee employee = new Employee();		
		employee.showDetails();		
		
		Employee employee1 = new Employee();		
		employee1.showDetails();
		
		
		Employee employee2 = new Employee(2222, "Mohan");
		employee2.showDetails();
		
		employee2.setEmpId(3333);
		employee2.setEmpName("Mohanee");
		
		int empId = employee2.getEmpId();
		String empName = employee2.getEmpName();
		System.out.println(empId + "\t --" + empName);
		employee2.showDetails();
		

	}

}
