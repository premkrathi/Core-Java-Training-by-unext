package com.banking;

public class Employee {
	//instance variables
	
	void show() {
		System.out.println("Showing Employee details.....");
	}
}
