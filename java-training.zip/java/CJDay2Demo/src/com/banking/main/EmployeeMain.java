package com.banking.main;

import java.util.Date;
import java.util.Scanner;
import com.banking.Employee;

//import java.util.*;
//import com.banking.*;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.show();
		
		Scanner scanner = new Scanner(System.in);
		Date date = new Date();
		System.out.println(date);
	}

}
