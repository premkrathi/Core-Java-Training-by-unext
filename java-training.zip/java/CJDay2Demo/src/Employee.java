public class Employee {
	//instance variables
	 private int empId;
	 private String empName;
	 
	 //no-arg constructor
	 public Employee(){
		System.out.println("Constructor invoked....");
		empId = 1000;
		empName = "Ram";
	 }
	 
	 //Parameterized Constructor
	 public Employee(int empId, String empName){		 	
			System.out.println("Parameterized Constructor invoked....");
			this.empId = empId;
			this.empName = empName;
		 }
	 
	 public void setEmpId(int empId) {
		 this.empId = empId;
	 }
	 public void setEmpName(String empName) {
		 this.empName = empName;		 
	 }
	 
	 public int getEmpId() {
		 return empId;
	 }
	 
	 public String getEmpName() {
		 return empName;
	 }
	 
	 
	 void showDetails() {
		 System.out.println(empId + "\t" + empName);
	 }
}
