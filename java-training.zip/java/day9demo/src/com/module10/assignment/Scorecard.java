package com.module10.assignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Scorecard {

	public static void main(String[] args) {
		Map <String , Integer> m1=new HashMap<>();
		m1.put("Rahane", 20);
		m1.put("Rahul" , 30);
		m1.put("Kohli", 150);
		m1.put("Dhoni", 50);
		m1.put("Lokesh", 2);

		System.out.println("Players Who Batted :");
		System.out.println(m1.keySet());
		System.out.println("\nScores By Players :");
		System.out.println(m1);
		int sum=0;
		String topper="";
		int maxrun=-1;
		for(int i1:m1.values() ) {
			if(i1> maxrun) {
				maxrun=i1;
			}
			sum+=i1;
		}
		Set s=m1.entrySet();
		Iterator i=s.iterator();
		while(i.hasNext()) {
			Map.Entry m= (Map.Entry) i.next();
			if((int)m.getValue()==maxrun) {
				topper=(String) m.getKey();
			}
		}
		System.out.println();
		System.out.println("Total Score:"+sum);
		System.out.println("High Scorer:"+	topper);
		System.out.println("Runs scored by Dhoni :"+m1.get("Dhoni"));
	
		
	}

}
