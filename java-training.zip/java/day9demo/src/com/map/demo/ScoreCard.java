package com.map.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class ScoreCard {

	public static void main(String[] args) {
		Score S1 = new Score("Rahane",20);
		Score S2 = new Score("Rahul",30);
		Score S3 = new Score("Kohli",150);
		Score S4 = new Score("Dhoni",50);
		Score S5 = new Score("Lokesh",2);
		
		Map<String,Score> scorecardMap=new TreeMap<>();
		scorecardMap.put(S1.getName(), S1);
		scorecardMap.put(S2.getName(), S2);
		scorecardMap.put(S3.getName(), S3);
		scorecardMap.put(S4.getName(), S4);
		scorecardMap.put(S5.getName(), S5);
		
		//System.out.println(scorecardMap);
		System.out.println("Players Who Batted :");
		
		for(Map.Entry<String,Score> entry :scorecardMap.entrySet()) {
			//System.out.println(entry.getKey()+"\t"+entry.getValue());
			Score sco =entry.getValue();
			System.out.println(sco.getName());
		}
		
		System.out.println("\nScores By Players :");
		
		for(Map.Entry<String,Score> entry :scorecardMap.entrySet()) {
			//System.out.println(entry.getKey()+"\t"+entry.getValue());
			Score sco =entry.getValue();
			System.out.println(sco.getName()+":"+sco.getruns());
		}
		
		
		
	}

}
