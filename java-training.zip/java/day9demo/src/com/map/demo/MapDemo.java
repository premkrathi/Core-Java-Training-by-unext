package com.map.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer,String> map =new HashMap();
		map.put(1, "Jake");
		map.put(6, "amy");
		map.put(3, "rosa");
		map.put(5, "charles");
		
		System.out.println(map);
	
		Map<String,String> friendsMap =new HashMap();
		friendsMap.put("1", "jake");
		friendsMap.put("6", "amy");
		friendsMap.put("3", "rosa");
		friendsMap.put("5", "charles");
		
		System.out.println(friendsMap);
		
		System.out.println(friendsMap.get("3"));
		//friendsMap.put("3", "Gina");
		//System.out.println(friendsMap.get("3"));
		
		//List<String> friends=(List<String>) friendsMap.values();
		
		Set<String>keys=friendsMap.keySet();
		//friendsMap.values();
		System.out.println(friendsMap.keySet());
		System.out.println(friendsMap.values());
		//System.out.println(friends);
		for(String key: keys ){
			System.out.println(key+","+friendsMap.get(key));
		}
		
		for ( Map.Entry<String,String> entry :friendsMap.entrySet() ) {
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}
		
		
	
	
	}

}
