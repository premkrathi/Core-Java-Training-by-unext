package com.map.demo;

import java.util.HashMap;
import java.util.Map;

public class EmployeeMapDemo {

	public static void main(String[] args) {
		Employee employee1= new Employee(111,"Ram",56432.90);
		Employee employee2= new Employee(345,"Narendra",86432.90);
		Employee employee3= new Employee(90,"Manohar",36432.90);
		//Employee employee1= new Employee(111,"Ram",56432.90);
		
		Map<Integer,Employee> employeeMap=new HashMap<>();
		employeeMap.put(employee1.getEmpId(), employee1);
		employeeMap.put(employee2.getEmpId(), employee2);
		employeeMap.put(employee3.getEmpId(), employee3);
		
		System.out.println(employeeMap);
	
		for(Map.Entry<Integer,Employee> entry :employeeMap.entrySet()) {
			//System.out.println(entry.getKey()+"\t"+entry.getValue());
			Employee emp =entry.getValue();
			System.out.println(emp.getEmpId()+"\t"+emp.getName()+"\t"+emp.getSalary());
		}
	
	}

}
