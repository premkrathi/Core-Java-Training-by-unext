package com.map.demo;

public class Score implements Comparable<Score> {
	private int runs;
	private String name;
	public Score() {}
	public Score(String name,int runs) {
		super();
		this.runs = runs;
		this.name = name;
	}
	public int getruns() {
		return runs;
	}
	public void setruns(int runs) {
		this.runs = runs;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int compareTo(Score score) {
		return Integer.valueOf(score.runs).compareTo(this.runs);
	}
	
	@Override
	public String toString() {
		return "Player name : " + name+"\tRuns Scored : " +runs ;
	}
	
	
}

