package com.functional.demo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class ComparatorDemo {



public static void main(String[] args) {
	List<Employee> employees = new ArrayList<>();
	Employee emp1 = new Employee(111, "Ram", 34567.00);
	Employee emp2 = new Employee(99, "Rama", 66567.00);
	Employee emp3 = new Employee(103, "Ramaya", 44567.00);

	employees.add(emp1);
	employees.add(emp2);
	employees.add(emp3);

	for(Employee employee : employees) {
		System.out.println(employee);
	}

/*Collections.sort(employees, (Employee e1, Employee e2) -> { return e1.getEmpId() - e2.getEmpId();});
System.out.println("After sorting.......");
for(Employee employee : employees) {
System.out.println(employee);
}*/
	Collections.sort(employees, (Employee e1, Employee e2) -> { return e1.getName().compareTo(e2.getName());});
	System.out.println("After sorting.......");
	for(Employee employee : employees) {
		System.out.println(employee);
		}

	}

}