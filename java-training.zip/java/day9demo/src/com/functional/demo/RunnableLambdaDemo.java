package com.functional.demo;

//public void run()
public class RunnableLambdaDemo {
public static void main(String[] args) {


Runnable runRef = () -> System.out.println("Welcome..." + Thread.currentThread().getName());

new Thread(runRef).start();
new Thread(runRef).start();



Runnable ref = () -> {
for(int i=1; i<=5; i++) {
System.out.println(Thread.currentThread().getName()+ "\t" + i);
try {
Thread.sleep(500);
} catch (InterruptedException e) {
e.printStackTrace();
}
}
};

new Thread(ref).start();



}



}