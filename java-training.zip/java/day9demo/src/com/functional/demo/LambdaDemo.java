package com.functional.demo;

interface I{
	void method(String message);
	
}
public class LambdaDemo {
	/*@Override
	public void method() {
		System.out.println("Hi Good Morning");
	}*/

	public static void main(String[] args) {
		
		//LambdaDemo demo=new LambdaDemo();
		//demo.method();
		I iObj1=(String message)->{ System.out.println(message);};
		iObj1.method("Hiiiiiiiii!!!!!!!!!!");
		
		I iObj2=message->{ System.out.println(message);};
		iObj2.method("Hiiiiiiiii!!!!!!!!!!");
		
		
		
	}

	
}
