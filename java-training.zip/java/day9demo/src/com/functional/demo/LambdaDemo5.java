package com.functional.demo;

import java.util.ArrayList;
import java.util.Scanner;
interface I5{
	void method();
}
public class LambdaDemo5 {
  public static void main(String[] args) {
  /*  ArrayList<Integer> numbers = new ArrayList<Integer>();
    Scanner m=new Scanner(System.in);
    System.out.print("Enter length Of Array :");
    int l =m.nextInt();
    System.out.print("Enter Elements of Array:");
    for(int i=0;i<l;i++) {
    numbers.add(m.nextInt());
    }
    System.out.println("Array Entered is:");
    
    numbers.forEach( (n) -> { System.out.print(n+"\t"); } );*/
  I5 obj=()->{
	  for(int i=1;i<11;i++) {
		  System.out.println(i);
	  }
  };
  obj.method();
  
  }
}