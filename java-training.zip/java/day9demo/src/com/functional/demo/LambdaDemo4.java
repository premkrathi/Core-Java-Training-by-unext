package com.functional.demo;

import java.util.Scanner;

interface I3{
	//void method(String message);
	int sum(int i,int j);
}
public class LambdaDemo4 {
	public static void main(String[] args) {
		I3 iObj1=(i,j)->{
			int k=i+j;
			return k;
			};
			System.out.print("Enter First Integer :");			
			Scanner m=new Scanner(System.in);
			int p=m.nextInt();
			System.out.print("Enter Second Integer :");			
			int q=m.nextInt();
			System.out.print("Sum of "+p+" & "+q+" is :");
			
			int result =iObj1.sum(p,q);
		System.out.println(result);
		
		
	}

	
}
