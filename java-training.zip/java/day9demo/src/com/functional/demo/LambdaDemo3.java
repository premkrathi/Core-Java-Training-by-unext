package com.functional.demo;

import java.util.Scanner;

interface I2{
	//void method(String message);
	int twice(int i);
}
public class LambdaDemo3 {
	/*@Override
	public void method() {
		System.out.println("Hi Good Morning");
	}*/

	public static void main(String[] args) {
		/*
		  int twice(int i){
		  i=i*2;
		  return i
		  }*/
		
		
		I2 iObj1=i->{
			i=i*2;
			return i;
			};
			System.out.print("Enter an Integer :");			
			Scanner m=new Scanner(System.in);
			int p=m.nextInt();
			System.out.print("2*"+p+"=");
			
			int result =iObj1.twice(p);
		System.out.println(result);
		
		
	}

	
}
