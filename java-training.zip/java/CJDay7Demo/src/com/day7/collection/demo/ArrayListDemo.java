package com.day7.collection.demo;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList friends = new ArrayList();
		friends.add("Ram");
		friends.add("Shyam");
		friends.add("Mohan");
		friends.add("Ram");
		
		System.out.println(friends.get(2));
		System.out.println(friends);
		
		for(int i=0; i<friends.size(); i++) {
			System.out.println(friends.get(i));
			//System.out.println(friends.get(i).toString().length());
		}
		
		System.out.println("Using Enhanced for loop..............");
		for(Object name: friends) {
			String friend = (String) name;
			System.out.println(friend);
		}
		System.out.println("Using Iterator ......................");
		Iterator iterator = friends.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		//ListIterator - (otherEmpIdspecific to List) Assignment 
	}

}
