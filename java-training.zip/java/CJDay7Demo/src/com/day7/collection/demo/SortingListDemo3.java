package com.day7.collection.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SortingListDemo3 {
	
	public static Book getBookDetails(int bookId, List<Book> books) {
		
		for(Book book : books) {
			if(book.getBookId()==bookId) {
				return book;
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		Book book1 = new Book(1111, "Spring Boot Primer", "Bala Gurusamy", 699.00);
		Book book2 = new Book(2314, "Spring Boot Fundamentals", "Shyama Gurusamy", 799.00);
		Book book3 = new Book(980, "AI in a Day", "Rama Gurusamy", 999.00);
		
		List<Book> books = new ArrayList<>();
		books.add(book1);
		books.add(book2);
		books.add(book3);
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter book id : - ");
		int bookId = scanner.nextInt();
		
		Book book = getBookDetails(bookId, books);
		if(book!=null) {
			System.out.println(book);
		}else {
			System.out.println("Book is not available");
		}
		
		
		
		
		/*Iterator<Book> iterator = books.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}*/
	}

}
