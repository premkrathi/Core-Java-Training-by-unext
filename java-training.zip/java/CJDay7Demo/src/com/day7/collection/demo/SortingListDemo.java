package com.day7.collection.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SortingListDemo {
	public static void main(String[] args) {
		ArrayList<String> friends = new ArrayList<>();
		friends.add("Ram");
		friends.add("Shyam");
		friends.add("Mohan");
		friends.add("Ram");
		
		for(String name: friends) {			
			System.out.println(name);
		}		
		
		Collections.sort(friends);
		System.out.println("After Sorting.......");
		for(String name: friends) {			
			System.out.println(name);
		}
		
		Employee employee1 = new Employee(103, "Manohar", 50000.00);
		Employee employee2 = new Employee(100, "Shiv", 150000.00);
		Employee employee3 = new Employee(101, "Aparna", 250000.00);
		
		List<Employee> employees = new ArrayList<>();
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		
		Collections.sort(employees);
		
		Iterator<Employee> iterator = employees.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
