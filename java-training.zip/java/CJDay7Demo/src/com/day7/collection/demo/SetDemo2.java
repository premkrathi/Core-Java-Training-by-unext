package com.day7.collection.demo;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo2 {
	public static void main(String[] args) {
		Employee employee1 = new Employee(103, "Manohar", 50000.00);
		Employee employee2 = new Employee(100, "Shiv", 150000.00);
		Employee employee3 = new Employee(101, "Aparna", 250000.00);
		
		Set<Employee> employees = new TreeSet<>();
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		
		Iterator<Employee> iterator = employees.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
		
		
		
		
		
	}

}
