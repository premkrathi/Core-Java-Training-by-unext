package com.day7.collection.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SortingListDemo2 {
	public static void main(String[] args) {
		Book book1 = new Book(1111, "Spring Boot Primer", "Bala Gurusamy", 699.00);
		Book book2 = new Book(2314, "Spring Boot Fundamentals", "Shyama Gurusamy", 799.00);
		Book book3 = new Book(980, "AI in a Day", "Rama Gurusamy", 999.00);
		
		List<Book> books = new ArrayList<>();
		books.add(book1);
		books.add(book2);
		books.add(book3);
		Collections.sort(books, new BookIdComparator());
		
		Iterator<Book> iterator = books.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
