package com.day7.collection.demo;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		Set<String> fruitBasket = new TreeSet<>();
		fruitBasket.add("Mango");
		fruitBasket.add("Banana");
		fruitBasket.add("Watermelon");
		fruitBasket.add("Strawberry");
		fruitBasket.add("Banana");//this will not be added in set -- ignored
		
		System.out.println(fruitBasket);
		Iterator iterator = fruitBasket.iterator();
		
		
		
		
		
		
	}

}
