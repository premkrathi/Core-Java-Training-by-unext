package com.day7.collection.demo;

import java.util.Comparator;

public class BookIdComparator implements Comparator<Book> {

	@Override
	public int compare(Book obj1, Book obj2) {
		return obj1.getBookId() - obj2.getBookId();
	}

}
