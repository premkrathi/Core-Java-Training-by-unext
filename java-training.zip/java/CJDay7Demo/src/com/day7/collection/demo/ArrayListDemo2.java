package com.day7.collection.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo2 {
	public static void main(String[] args) {
		Employee employee = new Employee();
		//ArrayList<Employee> friends = new ArrayList<Employee>();
		//friends.add(employee);
		
		//ArrayList<Integer> friends = new ArrayList<Integer>();
		//friends.add(11);
		
		ArrayList<String> friends = new ArrayList<>();
		friends.add("Ram");
		friends.add("Shyam");
		friends.add("Mohan");
		friends.add("Ram");
		/*friends.add(100);
		friends.add(true);
		friends.add(111.45f);
		friends.add(employee); */
		
		
		for(Object friend : friends) {
			String name = (String) friend;
			System.out.println(name.toUpperCase());
		}
		
		
		friends.remove(1);
		System.out.println("AFter removing....");
		System.out.println(friends);
		
		List<String> participants = new ArrayList<>();
		participants.add("Ramya");
		participants.add("Farha");
		participants.add("Lucy");
		
		friends.addAll(participants);
		
		System.out.println("Aftera adding participants...........................");
		System.out.println(friends);
		
		//removeAll
		//retainAll
		
		//add(index,element)
		//set(index,element)
		
		
		
	}

}
