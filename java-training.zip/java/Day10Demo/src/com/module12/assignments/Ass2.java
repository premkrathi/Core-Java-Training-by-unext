package com.module12.assignments;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class Ass2 {
public static void main(String[] args) throws ClassNotFoundException, SQLException {

Class.forName("oracle.jdbc.OracleDriver");
Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "hr");
Statement statement = connection.createStatement();

int prod_code= 106;
String prod_name= "Scanner" ;
double prod_price =2000.0;
String prod_catg ="Electronis";
Scanner fn=new Scanner(System.in);
/*System.out.println("Enter Product Details");
prod_code=fn.nextInt();
prod_name=fn.next();
prod_price=fn.nextInt();
prod_catg=fn.next();
*/
String query1= "insert into products values("+prod_code+",'"+prod_name+"',"+prod_price+",'"+prod_catg+"')";
System.out.println(query1);

int status = statement.executeUpdate(query1);
System.out.println(status);
connection.close();

}



}