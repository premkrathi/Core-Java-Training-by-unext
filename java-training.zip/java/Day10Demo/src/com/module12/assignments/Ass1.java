package com.module12.assignments;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Ass1 {
public static void main(String[] args) throws ClassNotFoundException, SQLException {

Class.forName("oracle.jdbc.OracleDriver");
Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "hr");
String query= "insert into products values(?,?,?,?)";
PreparedStatement preparedStatement = connection.prepareStatement(query);

preparedStatement.setInt(1, 101);
preparedStatement.setString(2, "Laptop");
preparedStatement.setString(3, "40000");
preparedStatement.setString(4, "Electronics");
int status = preparedStatement.executeUpdate();
System.out.println(status);

preparedStatement.setInt(1, 102);
preparedStatement.setString(2, "Keyboard");
preparedStatement.setString(3, "500");
preparedStatement.setString(4, "Electronics");
int s = preparedStatement.executeUpdate();
System.out.println(s);

preparedStatement.setInt(1, 103);
preparedStatement.setString(2, "Mouse");
preparedStatement.setString(3, "350");
preparedStatement.setString(4, "Electronics");
int st = preparedStatement.executeUpdate();
System.out.println(st);

preparedStatement.setInt(1, 104);
preparedStatement.setString(2, "T-Shirt");
preparedStatement.setString(3, "900");
preparedStatement.setString(4, "Clothing");
int stat = preparedStatement.executeUpdate();
System.out.println(stat);

preparedStatement.setInt(1, 105);
preparedStatement.setString(2, "Jeans");
preparedStatement.setString(3, "1500");
preparedStatement.setString(4, "Clothing");
int statu = preparedStatement.executeUpdate();
System.out.println(statu);


connection.close();

}



}