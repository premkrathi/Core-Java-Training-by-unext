package com.module12.assignments;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Ass3 {
public static void main(String[] args) throws ClassNotFoundException, SQLException {

Class.forName("oracle.jdbc.OracleDriver");
Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "hr");
Statement statement = connection.createStatement();

int prod_code;
String prod_name ;
double prod_price ;
String prod_catg ;
Scanner fn=new Scanner(System.in);
System.out.println("Enter No. Product Details to be added");
int n=fn.nextInt();

for(int i=0;i<n;i++) {
	System.out.println();
	System.out.println("Enter "+(i+1)+" Product Details");
	System.out.println();
	System.out.println("Enter Product Code");
	prod_code=fn.nextInt();
	System.out.println("Enter Product Name");
	prod_name=fn.next();
	System.out.println("Enter Product Price");
	prod_price=fn.nextInt();
	System.out.println("Enter Product Category");
	prod_catg=fn.next();

	String query1= "insert into products values("+prod_code+",'"+prod_name+"',"+prod_price+",'"+prod_catg+"')";
	System.out.println();
	System.out.println(query1);
	statement.executeUpdate(query1);
}
//int status = statement.executeUpdate(query1);
//System.out.println(status);
connection.close();

}

}