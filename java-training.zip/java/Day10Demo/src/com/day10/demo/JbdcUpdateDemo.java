package com.day10.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JbdcUpdateDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.OracleDriver");

		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "hr");

		Statement statement = connection.createStatement();
		String firstName="Bhaskar";
		int userId=200;
		
		String query = "update users set firstname= '"+firstName+"' where userid="+userId;
		System.out.println(query);
		
	}

}
