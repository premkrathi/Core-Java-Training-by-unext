package com.day10.demo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class JdbcDemo {
public static void main(String[] args) throws ClassNotFoundException, SQLException {

Class.forName("oracle.jdbc.OracleDriver");

Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "hr");

Statement statement = connection.createStatement();

int userId;
String firstName ;
String lastName;
String email ;
String password ;
Scanner fn=new Scanner(System.in);
System.out.println("Enter User Details");
userId=fn.nextInt();
firstName=fn.next();
lastName=fn.next();
email=fn.next();
password =fn.next();
//int marks = 200;
//String message = "Your score is " + marks;
//String query = "insert into users values(201,'Sanskriti','Bharti','pravesh@gmail.com','abc123')";

String query1= "insert into users values("+userId+",'"+firstName+"','"+lastName+"','"+email+"','"+password+"')";
System.out.println(query1);

int status = statement.executeUpdate(query1);
System.out.println(status);
connection.close();

}
}