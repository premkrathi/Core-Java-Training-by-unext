package File_Handling;

import java.util.*;

public class array {

	public static void main(String[] args) {
		Set<Integer> s = new LinkedHashSet<>();
		s.add(10);
		s.add(40);
		s.add(30);
		s.add(40);
		s.add(10);
		s.add(30);
		
		System.out.println(s);
		
		
	}

}
