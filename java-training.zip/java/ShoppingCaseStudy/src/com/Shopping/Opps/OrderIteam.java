package com.Shopping.Opps;


public class OrderIteam {
int orderId;
int productId;
int quantity;

}
