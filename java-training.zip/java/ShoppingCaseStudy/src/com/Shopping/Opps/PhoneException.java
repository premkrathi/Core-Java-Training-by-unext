package com.Unext.Opps;

public class PhoneException extends Exception {
 public void PhoneException () {
	 
 }
}
