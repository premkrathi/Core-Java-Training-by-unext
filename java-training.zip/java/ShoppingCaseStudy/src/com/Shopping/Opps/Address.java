package com.Shopping.Opps;

public class Address {
 String city;
 String State;
 int zip;
 String Country;
 
}
