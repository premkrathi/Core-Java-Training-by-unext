package com.exp;

public class TrainDoesNotexistException extends Exception {
public  String TrainDoesNotexistException() {
	return "Train does not exist";
}
}
