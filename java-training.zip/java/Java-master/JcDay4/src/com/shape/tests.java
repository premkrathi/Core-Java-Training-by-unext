package com.shape;

public class tests {
public static void main(String[] args) {
		
		Rectangle r1=new Rectangle();
		square s1=new square();
		
		s1.calcArea();
		s1.calcPeri();
		
		r1.calcArea();
		r1.calcPeri();
		
		
	}
}
