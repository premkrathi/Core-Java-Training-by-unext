package com.day6.basic.demo;

public class WrapperDemo {

	public static void main(String[] args) {
		int result = Integer.parseInt(args[0]) + Integer.parseInt(args[1]);
		System.out.println(result);
		
		Integer intObj = new Integer(123);
		
		int i = 123;
		Integer intObj1 = i; //autoboxing
		
		int j = intObj1; // unboxing
		
		
		double d = new Double(123.45); //unboxing
		
		
		
		
		
	}

}
