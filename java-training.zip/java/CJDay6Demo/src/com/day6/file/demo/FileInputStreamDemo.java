package com.day6.file.demo;

import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamDemo {
	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("datafile");
		
		/*int data = 0;
		while( data!= -1) {
			data = fis.read();			
			System.out.print((char)data);
		}*/
		
		int data = 0;
		while( (data = fis.read())!= -1) {						
			System.out.print((char)data);
		}
		
		
		fis.close();
	}

}
