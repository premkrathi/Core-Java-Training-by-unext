package com.day6.file.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamDemo {
	public static void main(String[] args) throws IOException {
		//write data to file
		
		String quote = "Java is beautiful language";
		byte[] info = quote.getBytes();
		
		File file = new File("datafile");
		
		//1. create
		//FileOutputStream fos = new FileOutputStream("datafile");
		FileOutputStream fos = new FileOutputStream(file, true);
		//2. use
		//fos.write(66);
		fos.write(info);
		//3. close
		fos.close();
		
		System.out.println("File Write successfull");
	}

}
