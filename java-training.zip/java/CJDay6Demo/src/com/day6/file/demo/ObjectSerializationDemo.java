package com.day6.file.demo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectSerializationDemo {

	public static void main(String[] args) throws IOException {
		Book book = new Book(111, "Learn Spring Boot", "Balaguru Swamy",499.00);
			
		FileOutputStream fos = new FileOutputStream("bookinfo");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(book);
		oos.close();
		System.out.println("State of object is written in the file....");
		
	}

}
