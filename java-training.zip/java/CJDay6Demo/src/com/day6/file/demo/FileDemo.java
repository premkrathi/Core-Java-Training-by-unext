package com.day6.file.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) throws IOException {
		File file = new File("myfile");
		file.createNewFile();
		
		File dir = new File("E:\\bajajdir");
		System.out.println(dir.mkdir());
		
		File file1 = new File(dir, "test");
		System.out.println(file1.createNewFile());
		
		System.out.println(file1.canWrite());
		System.out.println(file1.isDirectory());
		
		System.out.println(file.getAbsolutePath());
		System.out.println(file1.getAbsolutePath());
		
		
		
		
		
		
		
		
	}
}
