package com.day6.file.demo;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputDemo {
	private static final int BUFFER_SIZE = 1024;
	public static void main(String[] args) throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("data.txt"),BUFFER_SIZE);
		//bos.write(101);
		String quotation = "Honesty is best policy";
		//byte[] quoteArray = quotation.getBytes();
		bos.write(quotation.getBytes());
		bos.flush();
	}

}
