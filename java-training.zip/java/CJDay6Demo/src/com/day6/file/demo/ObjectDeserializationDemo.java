package com.day6.file.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectDeserializationDemo {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("bookinfo")));
		Book book = (Book) ois.readObject();
		System.out.println(book.getBookId() + "\t" + book.getAuthor()+"\t" + book.getPrice());
	
	}

}
