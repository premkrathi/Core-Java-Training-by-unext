package com.day6.file.demo;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class PrintWriterDemo {
	public static void main(String[] args) throws FileNotFoundException {
		//PrintWriter writer = new PrintWriter("test");
		PrintWriter writer = new PrintWriter(System.out);
		writer.println("Hi");
		
		int num = 12345;
		float val = 123.4567f;
		writer.format("%+,6d%n", num);
		writer.format("%.3f", val);
		writer.close();
	}

}
