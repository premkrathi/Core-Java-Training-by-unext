import java.util.*;
public class Test {
 public static void main(String[] args) {
  HashMap map = new HashMap(); //line 4
  map.put(18,1);
  map.put(15.5, 15.5);
  map.put(20, 20);
  map.put(45D, 50L);  
  Set set = map.keySet(); 
 //Arrays.sort(set);
  set=new TreeSet(set);  //line 10
  System.out.println(set);
 }
}