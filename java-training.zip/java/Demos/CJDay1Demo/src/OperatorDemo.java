public class OperatorDemo{
	public static void main(String[] args){
		System.out.println("Operator Demo");
		int i = 10;
		//++i;   // i = i + 1
		//	int j = ++i;
		int j = i++;
		System.out.println("i: " + i + "\tj:" + j); // i 11  j 10

		boolean flag = true;
		System.out.println(!flag);		
	}
}

