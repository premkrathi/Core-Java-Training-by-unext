
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int i = 10;
		
		int[] marks = new int[3];
		marks[0] = 97;
		marks[1] = 89;
		marks[2] = 96;
		
		/*
		System.out.println(marks[0]);
		System.out.println(marks[1]);
		System.out.println(marks[2]);
		*/
		//System.out.println(marks);
		int sum = 0;
		for(int i = 0; i<3; i++) {
			System.out.println(marks[i]);
			sum = sum + marks[i];
			//System.out.println("Sum : " + sum);
		}
		System.out.println("Sum : " + sum);
		
		
		String name = "Ram";
		
		System.out.println(name);
		
		/*
		String[] names = new String[3];
		names[0] = "Ram";
		names[1] = "Shyam";
		names[2] = "Mohan";
		
		for(int i = 0; i<3; i++) {
			System.out.println(names[i]);			
			
		}
		*/
		String[] names = {"Ram", "Shyam", "Mohan", "Manohar"};
		
		
		for(int i = 0; i<names.length; i++) {
			System.out.println(names[i]);			
			
		}
		
	}

}
