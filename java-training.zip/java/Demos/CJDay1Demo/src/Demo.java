import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		//System.out.println("Enter your name");
		String name = scanner.nextLine();
		
		//System.out.println("Enter your age");
		
		int age = scanner.nextInt();
		scanner.nextLine();
		
		//System.out.println("Your collage name");
		String collageName = scanner.nextLine();
		
		System.out.println("Your name is " + name + " Age " + age);
		System.out.println(collageName);
	}

}
