
public class TypeCastingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("Welcome");
		//range of byte : -128 to 127
		//implicit casting
		byte b = 10;
		int i = b;
		
		//explicit casting - can loose data 
		int j = 25600;
		byte c = (byte) j; //Type mismatch: cannot convert from int to byte
		
		System.out.println(j + "\t" + c); //0
		
		
		
		
		
		
		

	}

}
